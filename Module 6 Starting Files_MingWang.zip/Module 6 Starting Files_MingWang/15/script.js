/********f************

	Do not alter this comment block. 
	Only fill out the information below.
	
	Competency 15
	Name: Ming Wang 
    Date:Nov 14.2023
	Description: Implementation of an employee payroll entry system using JavaScript. 
	The script calculates gross pay with overtime, tax deductions, and net pay. 
	It dynamically updates a summary report table with employee payroll data.

********************/

document.addEventListener("DOMContentLoaded", load);

function load() {
	let calcButton = document.getElementById('calcButton');

	calcButton.addEventListener('click', calc);
	clearFields();

}

function calc() {
    let name = document.getElementById('fullName').value;
    let hours = parseFloat(document.getElementById('hoursWorked').value);
    let rate = parseFloat(document.getElementById('hourlyRate').value);

    if (!name || isNaN(hours) || isNaN(rate)) {
        clearFields();
        return;
    }

    let pay = calcPay(hours, rate);
    let taxes = getTax(pay);
    let net = pay - taxes;

    printRow(name, pay, taxes, net);
    clearFields();
}

function clearFields() {
    document.getElementById('fullName').value = "";
    document.getElementById('hoursWorked').value = "";
    document.getElementById('hourlyRate').value = "";
    document.getElementById('fullName').focus();
}


/*
	calcPay function
	receives hours and hourly rate values
	returns the calculated pay
*/
function calcPay(hours, rate) {
    let overtimeHours = Math.max(hours - 40, 0);
    let regularHours = hours - overtimeHours;
    let overtimeRate = rate * 1.5;
    return (regularHours * rate) + (overtimeHours * overtimeRate);
}


/*
	getTax function
	receives gross pay
	returns relative tax rate
*/
function getTax(funcGross) {
    let funcTax = 0;
    if (funcGross < 250) {
        funcTax = funcGross * .25;
    } else if (funcGross < 500) {
        funcTax = funcGross * .3;
    } else if (funcGross <= 750) {
        funcTax = funcGross * .4;
    } else {
        funcTax = funcGross * .5;
    }
    return funcTax;
}

/* 
	printRow function
	receives name, gross, taxes, and net pay
	formats currency
	prints a row in the table
*/
function printRow(name, gross, taxes, net) {
    let tbody = document.getElementsByTagName("tbody")[0];
    let tr = document.createElement("tr");
    let td = document.createElement("td");
    let td1 = document.createElement("td");
    let td2 = document.createElement("td");
    let td3 = document.createElement("td");

    td.innerHTML = name;
    td1.innerHTML = `$${gross.toFixed(2)}`;
    td2.innerHTML = `$${taxes.toFixed(2)}`;
    td3.innerHTML = `$${net.toFixed(2)}`;

    tr.appendChild(td);
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);

    tbody.appendChild(tr);
}

