/********f************

	Do not alter this comment block. 
	Only fill out the information below.

	Competency 13 Event Listeners
	Name: Ming Wang 
    Date:Nov 14.2023
	Description: Applying JavaScript event listeners and DOM manipulation to toggle element visibility.

*********************/

//	Task 1: Event listener to trigger the load function upon DOM loading
document.addEventListener('DOMContentLoaded', load);

/*	
	Task 2
	Load function
	Event listeners to setup the page will go here
*/
function load() {
	const button = document.querySelector('button');
    button.addEventListener('click', clickMe);
}

/*
	Task 3
	Click Function
	This will change the display value of the input
*/
function clickMe() {
	const input = document.getElementById('popup');
    
    // Toggle the display property of the input
    if (input.style.display === 'none' || input.style.display === '') {
        input.style.display = 'block';
    } else {
        input.style.display = 'none';
    }

}


