/********f************

    Do not alter this comment block. 
    Only fill out the information below.
    
    Competency 12 Javascript Syntax
    Name: Ming Wang 
    Date:Nov 14.2023
    Description: Demonstrating basic JavaScript syntax with arrays.

*********************/

// Array of favourite quotes
const quotes = [
    "The only way to do great work is to love what you do. - Steve Jobs",
    "Believe you can and you're halfway there. - Theodore Roosevelt",
    "It does not matter how slowly you go as long as you do not stop. - Confucius",
    "Everything you've ever wanted is on the other side of fear. - George Addair",
    "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill"
];

// Function to display quotes
function displayQuotes() {
    const quotesContainer = document.getElementById('quotes');
    quotesContainer.innerHTML = '<h4>Favorite Quotes:</h4>';
    quotes.forEach(quote => {
        quotesContainer.innerHTML += `<p>${quote}</p>`;
    });
}

displayQuotes();
