/********f************

    Do not alter this comment block. 
    Only fill out the information below.

    Competency 14 
    Name: Ming Wang 
    Date:Nov 14.2023
    Description: Demonstrating the creation, insertion, and deletion of DOM elements using JavaScript.

*********************/

document.addEventListener("DOMContentLoaded", load);

/*	
    Load function
    Create, insert, and delete elements
*/
function load() {

    // Create an element
    const pElement = document.createElement("p");
    pElement.textContent = "Lorem ipsum dolor sit amet...";
    const resultsContainer = document.getElementById("results");
    resultsContainer.appendChild(pElement);

    // Inserting
    const h2Element = document.createElement("h2");
    h2Element.textContent = "Header Text";
    resultsContainer.insertBefore(h2Element, pElement);

    // Deleting
    const footerElement = document.querySelector("footer");
    footerElement.parentNode.removeChild(footerElement);

}




