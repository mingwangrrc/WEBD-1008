document.addEventListener("DOMContentLoaded", function() {
    document.querySelector("form").addEventListener("submit", function(e) {
        e.preventDefault();

        // Validation logic here
        var name = document.getElementById('name').value;
        var phone = document.getElementById('phone').value;
        var email = document.getElementById('email').value;

        var errorMessages = [];
        if (!name) {
            errorMessages.push('Name is required');
        }
        if (!phone.match(/[0-9]{10}/)) {
            errorMessages.push('Phone number must be 10 digits');
        }
        if (!email.match(/^[^@]+@[^@]+\.[^@]+$/)) {
            errorMessages.push('Invalid email address');
        }

        if (errorMessages.length > 0) {
            alert(errorMessages.join("\n"));
            return false;
        }
        // Form is valid
        alert('Form submitted successfully!');
        return true;
    });
});
