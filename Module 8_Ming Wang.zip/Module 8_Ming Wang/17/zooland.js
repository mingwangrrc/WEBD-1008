/********f************

    Do not alter this comment block. 
    Only fill out the information below.

    Competency 17
    Name: Ming Wang 
    Date: Dec 10. 2023
    Description: This javascript file for WEBD-1008 JSON Zooland.

*********************/


/*
load function
loading the json file - run when the page loads
 */
function load() {
    fetch('zooland.json')
        .then(result => {
            return result.json()
        })
        .then(data => {
            createZooland(data);
        });
}

/*
    createZooland function
    This function will retrieve the data for the animal you created specifically
    You will then add the code required to meet the specifications
 */
function createZooland(zoolandData) {
    let contentDiv = document.getElementById('content');
    let myAnimal = zoolandData.find(animal => animal.common_name === "Red Panda");
    
    if (myAnimal) {
        let h2 = document.createElement('h2');
        h2.textContent = myAnimal.common_name;
        contentDiv.appendChild(h2);
    
        let h3 = document.createElement('h3');
        h3.textContent = myAnimal.scientific_name;
        contentDiv.appendChild(h3);
    
        let blockquote = document.createElement('blockquote');
        blockquote.textContent = myAnimal.description;
        contentDiv.appendChild(blockquote);
    
        myAnimal.images.image.forEach(imgSrc => {
        let img = document.createElement('img');
        img.src = 'images/' + imgSrc;
        img.style.width = '20%';
        contentDiv.appendChild(img);
        });
    }
}
    






//adds an event listener to execute onLoad method when page finished loading
document.addEventListener("DOMContentLoaded", load);

