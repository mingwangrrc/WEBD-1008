/********f************

    Do not alter this comment block. 
    Only fill out the information below.

    Competency 16
    Name: Ming Wang 
    Date: Dec 10. 2023 
    Description: This JavaScript file contains functions to interact with the Dog API.
*********************/


/*
    Load function
    Using the fetch API, get your chosen dataset from the Dog API
 */
    function load() {
        fetch('https://dog.ceo/api/breeds/image/random')
            .then(result => {
                return result.json();
            })
            .then(data => {
                createHTML(data);
            });
    }
    
    /*
        createHTML function
        Using your chosen Dog dataset, create at least 2 HTML elements 
        and add them to the provided HTML
    */
    function createHTML(data) {
        const wrapper = document.getElementById('wrapper');
    
        // Create image element
        const img = document.createElement('img');
        img.src = data.message; // Dog image URL
        wrapper.appendChild(img);
    
        // Create text element for breed
        const breed = document.createElement('p');
        breed.textContent = 'Breed: ' + data.message.split('/')[4]; // Extract breed from URL
        wrapper.appendChild(breed);
    }
    
    //adds an event listener to execute onLoad method when page finished loading
    document.addEventListener("DOMContentLoaded", load);
    